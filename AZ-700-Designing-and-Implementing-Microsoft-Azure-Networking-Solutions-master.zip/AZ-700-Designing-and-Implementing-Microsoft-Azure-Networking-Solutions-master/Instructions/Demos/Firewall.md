---
demo:
    module: 'Module 06 - Design and Implement Network Security'
    title: 'Firewall Manager (Module 06)'
---

**Reference:** [Tutorial: Secure your hub virtual network using Azure Firewall Manager](https://learn.microsoft.com/azure/firewall-manager/secure-cloud-network)
