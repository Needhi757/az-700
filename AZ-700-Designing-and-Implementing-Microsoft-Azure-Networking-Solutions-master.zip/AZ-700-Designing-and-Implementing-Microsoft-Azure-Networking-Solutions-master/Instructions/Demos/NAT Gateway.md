---
demo:
    module: 'Module 01 - Introduction to Azure Virtual Networks'
    title: 'NAT Gateway (Module 01)'
---
In this demonstration review the NAT gateway.

**Reference:** [Tutorial: Create a NAT gateway - Azure portal](https://learn.microsoft.com/azure/virtual-network/nat-gateway/tutorial-create-nat-gateway-portal)

