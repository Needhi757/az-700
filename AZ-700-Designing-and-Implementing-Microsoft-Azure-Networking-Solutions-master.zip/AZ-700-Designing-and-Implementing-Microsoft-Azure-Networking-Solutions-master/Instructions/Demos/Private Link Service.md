---
demo:
    title: 'Private Link Service (Module 07)'
    module: 'Demo: Design and implement private access to Azure Services'
---
In this demonstration review configuring private link. 

**Reference:** [Quickstart - Create a Private Link service by using the Azure portal](https://learn.microsoft.com/azure/private-link/create-private-link-service-portal)

**Reference:** [Quickstart - Create a Private Endpoint using the Azure portal](https://learn.microsoft.com/azure/private-link/create-private-endpoint-portal)

