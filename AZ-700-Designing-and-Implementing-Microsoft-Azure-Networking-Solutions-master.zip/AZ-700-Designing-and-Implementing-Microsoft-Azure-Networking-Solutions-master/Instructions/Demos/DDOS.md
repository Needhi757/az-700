---
demo:
    module: 'Module 06 - Design and Implement Network Security'
    title: 'DDOS Network Protection (Module 06)'
---
## Configure DDoS network protection

In this demonstration, you review configuring DDoS network protection.

**Reference:** [DDOS Network Protection](https://learn.microsoft.com/azure/ddos-protection/manage-ddos-protection)

**Reference:** [QuickStart: Create and configure Azure DDoS Network Protection using the Azure portal](https://learn.microsoft.com/azure/ddos-protection/manage-ddos-protection)
