---
demo:
    title: 'Front Door (Module 05)'
    module: 'Module 05 - Load balancing HTTPS traffic'
---
In this demonstration review configuring Front Door.

**Reference:** [Quickstart: Create an Azure Front Door using Azure portal](https://learn.microsoft.com/en-us/azure/frontdoor/create-front-door-portal)

**Reference:** [Quickstart: Create an Azure Front Door (classic) using the Azure portal](https://learn.microsoft.com/en-us/azure/frontdoor/quickstart-create-front-door)
