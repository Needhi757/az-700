---
demo:
    title: 'Traffic Manager (Module 04)'
    module: 'Module 04 - Load balancing non-HTTPS traffic'
---

**Reference:** [Quickstart: Create a profile for HA of applications - Azure portal - Azure Traffic Manager](https://learn.microsoft.com/azure/traffic-manager/quickstart-create-traffic-manager-profile)

