---
demo:
    title: 'Service Endpoints (Module 07)'
    module: 'Module 07 - Design and implement private access to Azure Services'
---

**Reference:** [Restrict access to PaaS resources - tutorial](https://learn.microsoft.com/azure/virtual-network/tutorial-restrict-network-access-to-resources?tabs=portal)

