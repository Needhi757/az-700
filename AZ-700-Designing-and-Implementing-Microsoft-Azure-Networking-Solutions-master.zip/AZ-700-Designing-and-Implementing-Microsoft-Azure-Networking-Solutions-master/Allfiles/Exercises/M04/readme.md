vm-template
